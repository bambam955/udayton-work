#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

static char buf[512];

int
main(int argc, char *argv[])
{
    // EXPECTED OUTPUT: "512 bytes, <>" because it will read 512 bytes but 
    // all of them will be \0 and thus not actually print
    int devZeroFd = open("dev/zero", O_RDONLY);
    if (devZeroFd >= 0)
    {
        int bytesRead = read(devZeroFd, buf, 512);
        if (bytesRead > 0)
        {
            printf(1, "dev/zero output: %d bytes, <%s>\n", bytesRead, buf);
        }
        else
        {
            printf(2, "Error: could not read from dev/zero\n");
        }
        close(devZeroFd);
    }
    else
    {
        printf(2, "Error: could not open dev/zero\n");
    }

    // EXPECTED OUTPUT: "wrote 23 bytes", because the string is 23 bytes long.
    // Of course, dev/null will just swallow the input, but write() doesn't know (or care).
    int devNullFd = open("dev/null", O_WRONLY);
    if (devNullFd >= 0)
    {
        int bytesWritten = write(devNullFd, "this is a great project", 23);
        if (bytesWritten > 0)
        {
            printf(1, "wrote %d bytes to dev/null\n", bytesWritten);
        }
        else
        {
            printf(2, "Error: could not write to dev/null\n");
        }
        close(devNullFd);
    }
    else
    {
        printf(2, "Error: could not open dev/null\n");
    }

    // EXPECTED OUTPUT: whatever the current tick counter is, with bytes being 
    // one more than actual string length because of the terminating \0 character
    int devTicksFd = open("dev/ticks", O_RDONLY);
    if (devTicksFd >= 0)
    {
        int bytesRead = read(devTicksFd, buf, 512);
        if (bytesRead >= 0)
        {
            printf(1, "dev/ticks output: %d bytes, <%s>, length %d\n", bytesRead, buf, strlen(buf));
        }
        else
        {
            printf(2, "Error: could not read from dev/ticks\n");
        }
        close(devTicksFd);
    }
    else
    {
        printf(2, "Error: could not open dev/ticks\n");
    }

    exit();
}
