# Command to compile the program:
gcc countUD.c -o countUD

# Command to run the program:
./countUD /usr/share/*/*

# Or, just use the run.sh script to do it all for you:
./run.sh
