#!/bin/bash

gcc countUD.c -o countUD
./countUD /usr/share/*/*
rm countUD
